import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os

# ---------- BASIC PAGE SETUP ----------
st.set_page_config(
    page_title="EMIPredict AI",
    layout="wide"
)

st.title("💰 EMIPredict AI – Intelligent Financial Risk Assessment")
st.write("Predict EMI eligibility and maximum safe monthly EMI")

# ---------- LOAD MODELS SAFELY ----------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    clf_model = joblib.load(os.path.join(BASE_DIR, "best_classification_model.pkl"))
    reg_model = joblib.load(os.path.join(BASE_DIR, "best_regression_model.pkl"))
    scaler = joblib.load(os.path.join(BASE_DIR, "scaler.pkl"))
    feature_names = joblib.load(os.path.join(BASE_DIR, "feature_names.pkl"))
except Exception as e:
    st.error("❌ Model loading failed")
    st.write(e)
    st.stop()

# ---------- SIDEBAR INPUTS ----------
st.sidebar.header("Customer Details")

age = st.sidebar.number_input("Age", 18, 65, 30)
monthly_salary = st.sidebar.number_input("Monthly Salary (INR)", 10000, 300000, 50000)
credit_score = st.sidebar.number_input("Credit Score", 300, 850, 700)

current_emi = st.sidebar.number_input("Current EMI Amount", 0, 100000, 5000)
school_fees = st.sidebar.number_input("School Fees", 0, 50000, 0)
college_fees = st.sidebar.number_input("College Fees", 0, 80000, 0)
travel_expenses = st.sidebar.number_input("Travel Expenses", 0, 30000, 3000)
groceries_utilities = st.sidebar.number_input("Groceries & Utilities", 0, 40000, 8000)
other_monthly_expenses = st.sidebar.number_input("Other Expenses", 0, 30000, 2000)

# ---------- FEATURE ENGINEERING ----------
total_expenses = (
    school_fees +
    college_fees +
    travel_expenses +
    groceries_utilities +
    other_monthly_expenses +
    current_emi
)

expense_to_income = total_expenses / monthly_salary
debt_to_income = current_emi / monthly_salary

# ---------- CREATE FULL FEATURE VECTOR ----------
input_dict = dict.fromkeys(feature_names, 0)

input_dict["age"] = age
input_dict["monthly_salary"] = monthly_salary
input_dict["credit_score"] = credit_score
input_dict["current_emi_amount"] = current_emi
input_dict["school_fees"] = school_fees
input_dict["college_fees"] = college_fees
input_dict["travel_expenses"] = travel_expenses
input_dict["groceries_utilities"] = groceries_utilities
input_dict["other_monthly_expenses"] = other_monthly_expenses
input_dict["total_expenses"] = total_expenses
input_dict["expense_to_income"] = expense_to_income
input_dict["debt_to_income"] = debt_to_income

input_df = pd.DataFrame([input_dict])

# ---------- SCALE INPUT ----------
input_scaled = scaler.transform(input_df)

# ---------- PREDICTION ----------
if st.button("🔍 Predict EMI"):
    eligibility = clf_model.predict(input_scaled)[0]
    max_emi = reg_model.predict(input_scaled)[0]

    st.subheader("📊 Prediction Result")

    if eligibility == 0:
        st.success("✅ EMI Status: ELIGIBLE")
    elif eligibility == 1:
        st.warning("⚠️ EMI Status: HIGH RISK")
    else:
        st.error("❌ EMI Status: NOT ELIGIBLE")

    st.info(f"💸 Maximum Safe Monthly EMI: ₹ {int(max_emi)}")
